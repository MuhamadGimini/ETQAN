
import { formatDateForDisplay } from '../utils';
import type { CompanyData } from '../types';

/**
 * Generates a standardized HTML template for reports with consistent styling.
 */
export const getReportPrintTemplate = (
    title: string, 
    subtitle: string, 
    companyData: CompanyData, 
    tableHeaders: string[], 
    tableRowsHtml: string,
    summaryHtml?: string,
    secondarySummaryHtml?: string,
    signaturesHtml?: string,
    pageSize: string = 'A4'
) => {
    return `
        <html dir="rtl">
        <head>
            <title>${title}</title>
            <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">
            <style>
                @page {
                    size: ${pageSize};
                    margin: 1cm;
                }
                body { 
                    font-family: 'Cairo', sans-serif; 
                    padding: 0; 
                    color: #333;
                    -webkit-print-color-adjust: exact;
                    print-color-adjust: exact;
                    background-color: white;
                }
                .report-header {
                    text-align: center;
                    margin-bottom: 20px;
                    border-bottom: 2px solid #1e3a8a;
                    padding-bottom: 10px;
                }
                .report-header h1 {
                    font-size: 1.6rem;
                    font-weight: 900;
                    color: #1e3a8a;
                    margin: 0;
                }
                .report-header h2 {
                    font-size: 1.2rem;
                    font-weight: 700;
                    color: #1e3a8a;
                    margin: 5px 0;
                }
                .report-header p {
                    font-size: 10pt;
                    color: #555;
                    margin: 2px 0;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 15px 0;
                    border: 1px solid #1e3a8a;
                }
                th {
                    background-color: #1e3a8a !important;
                    color: white !important;
                    font-weight: 900;
                    padding: 8px;
                    border: 1px solid #1e3a8a;
                    text-align: center;
                    font-size: 11pt;
                }
                td {
                    padding: 8px;
                    border: 1px solid #ddd;
                    text-align: center;
                    font-size: 10pt;
                    font-weight: 700;
                }
                tr:nth-child(even) {
                    background-color: #f1f5f9 !important;
                }
                .summary-section {
                    margin-top: 15px;
                    display: flex;
                    justify-content: flex-end;
                }
                .summary-box {
                    border: 1px solid #1e3a8a;
                    border-radius: 8px;
                    padding: 10px;
                    background-color: #f8fafc;
                    width: 280px;
                }
                .summary-item {
                    display: flex;
                    justify-content: space-between;
                    padding: 4px 0;
                    border-bottom: 1px dashed #ddd;
                    font-weight: bold;
                    font-size: 11pt;
                }
                .summary-item:last-child {
                    border-bottom: none;
                    border-top: 2px solid #1e3a8a;
                    margin-top: 5px;
                    padding-top: 8px;
                    color: #1e3a8a;
                    font-size: 12pt;
                }
                .footer {
                    margin-top: 40px;
                    border-top: 2px solid #1e3a8a;
                    padding-top: 10px;
                    text-align: center;
                    font-size: 9pt;
                    font-weight: bold;
                }
                .text-right { text-align: right; }
                .text-left { text-align: left; }
                .font-black { font-weight: 900; }
                .text-indigo { color: #1e3a8a; }
                .text-red { color: #dc2626; }
                .text-green { color: #16a34a; }
                .text-blue { color: #2563eb; }
            </style>
        </head>
        <body onload="window.print();window.close()">
            <div class="report-header">
                <h1>${companyData.name}</h1>
                <h2>${title}</h2>
                <p>${subtitle}</p>
                <p>تاريخ الطباعة: ${formatDateForDisplay(new Date().toISOString().split('T')[0])}</p>
            </div>
            <table>
                <thead>
                    <tr>
                        ${tableHeaders.map(h => `<th>${h}</th>`).join('')}
                    </tr>
                </thead>
                <tbody>
                    ${tableRowsHtml}
                </tbody>
            </table>
            ${(summaryHtml || secondarySummaryHtml) ? `
                <div class="summary-section" style="justify-content: ${(summaryHtml && secondarySummaryHtml) ? 'space-between' : 'flex-end'}">
                    ${secondarySummaryHtml ? `
                    <div class="summary-box">
                        ${secondarySummaryHtml}
                    </div>
                    ` : ''}
                    ${summaryHtml ? `
                    <div class="summary-box">
                        ${summaryHtml}
                    </div>
                    ` : ''}
                </div>
            ` : ''}
            
            ${signaturesHtml ? `
                <div class="signatures-section">
                    ${signaturesHtml}
                </div>
            ` : ''}

            <div class="footer">
                <p>${companyData.address} | ${companyData.phone1}</p>
            </div>
        </body>
        </html>
    `;
};
